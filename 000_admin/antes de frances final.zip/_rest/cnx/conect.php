<?php
       

$usuario_bd = "admin_fuster_version2";
$contrasena_bd = "Ysr7f!78MlXkoubo";
$servidor_bd = "localhost";
$basededatos_bd = "admin_fuster_version2";


    $cxn_bd = new mysqli($servidor_bd, $usuario_bd, $contrasena_bd, $basededatos_bd);
    if ($cxn_bd->connect_error) { die("Connection failed: " . $cxn_bd->connect_error); }

    
?>