<?php

if (isset($_POST['action']) && ($_POST['action'] == 'process')) {

    $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify'; 
    $recaptcha_secret = '6Ld5Iq8jAAAAAAL8W_NgUyns3dWNMcikV4HuCJFh'; 
    $recaptcha_response = $_POST['recaptcha_response']; 
    $recaptcha = file_get_contents($recaptcha_url . '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response); 
    $recaptcha = json_decode($recaptcha); 
    var_dump($recaptcha);
    
    if($recaptcha->score >= 0.7){
    
        // código para procesar los campos y enviar el form
        echo "// código para procesar los campos y enviar el form";
    } else {
    
      // código para lanzar aviso de error en el envío
      echo "// código para lanzar aviso de error en el envío";
    }
    
    }

?>